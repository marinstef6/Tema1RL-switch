#!/usr/bin/python3
import sys
import struct
import wrapper
import threading
import time
import os
from wrapper import recv_from_any_link, send_to_link, get_switch_mac, get_interface_name

LISTENING = 1
BLOCKING = 0

# Variabile globale pentru a fi folosite in mai multe functii
own_bid = b'\x00'
root_path_cost = 0
root_port = -1
root_bid = b'\x00'
# Initializare interfata
interfaces = range(0)
# Initializare VLAN
vlans = []
# Interfata states
states = []
# Initializare MAC_Table
MAC_Table = {}

def parse_ethernet_header(data):
    # Unpack the header fields from the byte array
    #dest_mac, src_mac, ethertype = struct.unpack('!6s6sH', data[:14])
    dest_mac = data[0:6]
    src_mac = data[6:12]
    
    # Extract ethertype. Under 802.1Q, this may be the bytes from the VLAN TAG
    ether_type = (data[12] << 8) + data[13]

    vlan_id = -1
    # Check for VLAN tag (0x8100 in network byte order is b'\x81\x00')
    if ether_type == 0x8200:
        vlan_tci = int.from_bytes(data[14:16], byteorder='big')
        vlan_id = vlan_tci & 0x0FFF  # extract the 12-bit VLAN ID
        ether_type = (data[16] << 8) + data[17]

    return dest_mac, src_mac, ether_type, vlan_id

def create_vlan_tag(vlan_id):
    # 0x8100 for the Ethertype for 802.1Q
    # vlan_id & 0x0FFF ensures that only the last 12 bits are used
    return struct.pack('!H', 0x8200) + struct.pack('!H', vlan_id & 0x0FFF)

def send_bdpu_every_sec():
    global vlans, interfaces
    while True:
        # TODO Send BDPU every second if necessary
        # Verificam daca suntem in switch-ul root si daca nu suntem asteptam
        if own_bid != root_bid:
            time.sleep(1)
            continue
        for i in interfaces:
            # daca vlan-ul este trunk trimitem BPDU
            if vlans[i] == 'T':
                #cream pachetul
                packet = bpdu_create(own_bid, get_switch_mac(), i, 0, own_bid)
                send_to_link(i, len(packet), packet)
        time.sleep(1)

def bpdu_create(sender_bridge_id, src_mac, port_id, root_path_cst, root_bridge_id):
    # Transforma adresa MAC de destinatie in bytes
    dest_mac = bytes([int(b, 16) for b in "01:80:c2:00:00:00".split(':')])

    # Definirea componentelor implicite BPDU
    llc_header = b'\x42\x42\x03'      # Header LLC
    bpdu_header = b'\x00\x00\x00\x00' # Header BPDU
    flags = b'\x00'                   # Steaguri implicite
    unused = b'\x00' * 8              # Byte-uri nefolosite (padding)

    # Conversie valori variabile in bytes
    root_path_cost_bytes = root_path_cst.to_bytes(4, 'big')
    port_id_bytes = port_id.to_bytes(2, 'big')

    # Constructia partii BPDU
    bpdu_part = (
        llc_header + bpdu_header + flags + root_bridge_id +
        root_path_cost_bytes + sender_bridge_id + port_id_bytes + unused
    )

    # Calculeaza si transforma lungimea BPDU in bytes
    llc_length = len(bpdu_part).to_bytes(2, 'big')

    # Construieste si returneaza pachetul complet BPDU
    packet = dest_mac + src_mac + llc_length + bpdu_part
    return packet

def bpdu_received(data, interface_received):

    # Obtinem BID si costul din pachet
    global own_bid, root_bid, root_path_cost, root_port
    global MAC_Table, interfaces, vlans, states

    # Verificam daca am primit un root id mai bun
    if data[22:30] < root_bid:
        # Verificam daca ne consideram root
        if root_bid != own_bid:
            we_were_root = False
        else:
            we_were_root = True

        # Actualizam costul curent si root id
        root_bid = data[22:30]
        root_path_cost = 10 + int.from_bytes(data[30:34], 'big')
        root_port = interface_received
        #Setam portul curent la starea LISTENING
        states[root_port] = LISTENING

        if we_were_root:
            #Setam toate porturile in starea BLOCKING in afara de root port
            for i in interfaces:
                if vlans[i] == 'T':
                    if i != root_port:
                        states[i] = BLOCKING

        # TRimitem un nou pachet BPDU catre toti vecinii
        for i in interfaces:
            if vlans[i] == 'T':
                if i != interface_received:
                # Cream si trimitem pachetul BPDU
                    packet = bpdu_create(own_bid, get_switch_mac(), i, root_path_cost, root_bid)
                    send_to_link(i, len(packet), packet)
    
    # Root-ul este acelasi dar se poate actualiza costul si portul 
    # root
    if data[22:30] == root_bid:
        # Daca pachetul a fost primit pe root port verificam daca actualizam costul
        if interface_received == root_port:
            if int.from_bytes(data[30:34], 'big') + 10 < root_path_cost:
                root_path_cost = int.from_bytes(data[30:34], 'big') + 10
    # Daca pachetul nu a fost primit pe root, verificam daca suntem 
    # pe drumul catre root
        elif interface_received != root_port:
            if int.from_bytes(data[30:34], 'big') > root_path_cost:
                # Daca suntem in calea altor entitati catre root schimbam 
                # starea porturilor
                if states[interface_received] == BLOCKING:
                    states[interface_received] = LISTENING
    # Daca BID-ul coincide cu cel din pachet, setam starea portului
    if data[34:42] == own_bid:
        states[interface_received] = BLOCKING
    # Daca suntem root, setam root_port la -1 si toate porturile la LISTENING
    if own_bid == root_bid:
        root_port = -1
        index = 0
        while index < len(interfaces):
            states[interfaces[index]] = LISTENING
            index += 1

def parse_file(switch_id):
    vlan_list = []
    file_path = os.path.join(os.getcwd(), 'configs', f'switch{switch_id}.cfg')

    with open(file_path, "r") as file:
        # Citim prioritatea din prima linie
        first_line = file.readline().strip()
        switch_priority = int(first_line)
        # Parcurgem restul liniilor si salvam VLAN-urile
        for line in file:
            line = line.strip()
            if line:
                vlan_info = line.split()
                if len(vlan_info) > 1:
                    vlan_list.append(vlan_info[1])
    
    return switch_priority, vlan_list

def destination_unfound_yet(interface, data, length):
    global MAC_Table, interfaces, vlans, states

    # Verificam daca pachetul a fost primit pe un link de tip acces
    if vlans[interface] != 'T':
        index = 0
        # Salvam VLAN-ul interfetei de receptie si adaugam un tag VLAN la pachet
        # pentru a putea fi transmis pe linkurile trunk
        vlan_id = int(vlans[interface])
        tagged_frame = data[0:12] + create_vlan_tag(vlan_id) + data[12:]

        while index < len(interfaces):
            iface = interfaces[index]
        
        # Sarim peste interfata de receptie
            if iface != interface:
            # Daca interfata este trunk si in starea LISTENING, trimitem pachetul
            # cu tagging
                if vlans[iface] == 'T':
                    if states[iface] == LISTENING:
                    # Trimitem de pe access pe trunk cu tagging
                        send_to_link(iface, length + 4, tagged_frame)
                elif vlans[iface] == vlans[interface]:
                    send_to_link(iface, length, data)
        
            index += 1
    else:
    # Pachet primit pe un link de tip trunk
        index = 0
        # Indepartam tag-ul VLAN pentru a putea sa il transmitem pe linkurile 
        # de tip access
        untagged_frame = data[0:12] + data[16:]

        while index < len(interfaces):
            iface = interfaces[index]
            
            if iface != interface:
                if vlans[iface] == 'T' and states[iface] == LISTENING:
                    # Trimitem de la trunk la trunk
                    send_to_link(iface, length, data)
                elif vlans[iface] != 'T' and int(vlans[iface]) == int.from_bytes(data[14:16], byteorder='big'):
                    send_to_link(iface, length - 4, untagged_frame)
            
            index += 1
    
def main():
    # init returns the max interface number. Our interfaces
    # are 0, 1, 2, ..., init_ret value + 1
    switch_id = sys.argv[1]

    global MAC_Table, interfaces, vlans, states
    global own_bid, root_bid, root_path_cost, root_port

    # Initializam interfetele de pe switch
    num_interfaces = wrapper.init(sys.argv[2:])
    interfaces = range(0, num_interfaces)
    # Citim prioritatea si VLAN-urile din fisier
    priority, vlans = parse_file(switch_id)
    
    # Initializam BPDU
    while len(states) < num_interfaces:
        states.append(BLOCKING)
            
    # Setam propriul BID si root BID
    own_bid = priority.to_bytes(2, 'big') + get_switch_mac()
    root_bid = own_bid
    
    # Daca suntem root, setam toate porturile in starea LISTENING
    if own_bid == root_bid:
        for i in range(num_interfaces):
            states[i] = LISTENING

    # Create and start a new thread that deals with sending BDPU
    t = threading.Thread(target=send_bdpu_every_sec)
    t.start()

    # Printing interface names

    while True:
        # Note that data is of type bytes([...]).
        # b1 = bytes([72, 101, 108, 108, 111])  # "Hello"
        # b2 = bytes([32, 87, 111, 114, 108, 100])  # " World"
        # b3 = b1[0:2] + b[3:4].

        # receive packet
        interface, data, length = recv_from_any_link()
        dest_mac, src_mac, ethertype, vlan_id = parse_ethernet_header(data)

        # Print the MAC src and MAC dst in human readable format
        dest_mac = ':'.join(f'{b:02x}' for b in dest_mac)
        src_mac = ':'.join(f'{b:02x}' for b in src_mac)

        # Note. Adding a VLAN tag can be as easy as
        # tagged_frame = data[0:12] + create_vlan_tag(10) + data[12:]

        # TODO: Implement forwarding with learning
        # TODO: Implement VLAN support
        # TODO: Implement STP support

        # data is of type bytes.
        # send_to_link(i, length, data)

        # Verificam daca am primit un BPDU
        if dest_mac == "01:80:c2:00:00:00":
            # Am primit un BPDU
            bpdu_received(data, interface)
            continue

        # Realizam forwarding
        MAC_Table[src_mac] = interface

        # Verificam daca destinatia este un broadcast
        if dest_mac == "ff:ff:ff:ff:ff:ff":
            destination_unfound_yet(interface, data, length)

        # Verificam daca MAC-ul de destinatie este in tabelul MAC
        if dest_mac in MAC_Table:
            dest_iface = MAC_Table[dest_mac]
            
            # Verificam daca interfata de destinatie este diferita de cea de 
            # receptie
            if interface != dest_iface:
                # Verificam daca interfata de destinatie este in starea LISTENING
                if states[dest_iface] == LISTENING:
                    source_vlan = vlans[interface]
                    dest_vlan = vlans[dest_iface]

                    # Verificam daca sursa este trunk
                    if source_vlan == 'T':
                        # Verificam daca destinatia este trunk
                        if dest_vlan == 'T':
                            send_to_link(dest_iface, length, data)
                        
                        # Daca destinatia este access
                        if dest_vlan != 'T':
                            untagged_frame = data[0:12] + data[16:]
                            if int(vlans[dest_iface]) == int.from_bytes(data[14:16], byteorder='big'):
                                send_to_link(dest_iface, length - 4, untagged_frame)
                        
                    # Daca sursa este access
                    if source_vlan != 'T':
                        # Daca destinatia este trunk
                        if dest_vlan == 'T':
                            tagged_frame = data[0:12] + create_vlan_tag(int(source_vlan)) + data[12:]
                            send_to_link(dest_iface, length + 4, tagged_frame)
                        # Daca atat sursa, cat si destinatia sunt in acelasi VLAN access
                        if dest_vlan == source_vlan:
                            send_to_link(dest_iface, length, data)

        # Daca nu este in tabelul MAC sau este broadcast
        if dest_mac not in MAC_Table and dest_mac != "ff:ff:ff:ff:ff:ff":
            destination_unfound_yet(interface, data, length)

if __name__ == "__main__":
    main()
